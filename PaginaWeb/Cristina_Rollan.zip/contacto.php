<?php include 'header.php'; ?>
    <section>
        <h1>Contacto</h1>
        <address>
            <p>Dirección: Eduardo Barreiros, 17, 28041 Madrid, España</p>
        </address>
        <iframe src="https://www.google.com/maps/d/u/0/embed?mid=1mMcjHa-8Gxa5fYe8GEbYZRW_50CX8-0&ehbc=2E312F" width="640" height="480"></iframe>
    </section>
<?php include 'footer.php'; ?>