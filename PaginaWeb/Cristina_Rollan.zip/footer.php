<html>
    <body>
        <footer>
            <p>Email de contacto: <?php echo ("cristina.rollan@educa.madrid.org");?> &copy; <?php echo date ("Y");?></p>
        </footer>
    </body>
</html>
