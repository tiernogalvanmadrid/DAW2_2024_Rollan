<?php include 'header.php'; ?>
    <section>
        <h1>Pagina web con php</h1>
        <p>mi primera pagina web</p>
    </section>
<?php include 'footer.php'; ?>