<!DOCTYPE html>
    <head>
        <title>Tu Sitio Web</title>
        <link rel="stylesheet" type="text/css" href="css\styles.css">
        <meta charset="UTF-8">
    </head>
    <body>
        <header>
            <nav>
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="calificaciones.php">Calificaciones</a></li>
                    <li><a href="contacto.php">Contacto</a></li>
                </ul>
            </nav>
        </header>
    </body>
</html>
