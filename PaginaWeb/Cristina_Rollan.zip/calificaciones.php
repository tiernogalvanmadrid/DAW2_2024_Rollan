<?php include 'header.php'; ?>

<section>
    <h1>Calificaciones</h1>
    <p>Contenido de calificaciones en formato texto.</p>
    <p>Calificación: 9.5/10</p>
</section>

<?php include 'footer.php'; ?>